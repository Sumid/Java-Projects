package murach.games.business;

import java.util.Random;

public class NumberGame {
    // cannot find symbol error. Spelling error iny to int
    private int number;
    private int guessCount;
    
    public NumberGame(int upperLimit) {
        Random random = new Random();
        number = random.nextInt(upperLimit + 1);
        guessCount = 1;

    }

    public int getNumber() {
        // semicolon is missing after number(;).
        return number;
    }

    public int getGuessCount() {
        return guessCount;
    }
    
    public void incrementGuessCount() {
        guessCount = guessCount + 1;
    }
}