package com.murach.testing;

import java.util.Random;
//Sumid Dhungel
//Experiment with the code tester application
//08/25/19
//Working with arithmetic expressions, escape sequences, assignment statement.
//Also, calculating the area of a rectangle.

public class CodeTesterApp {

    public static void main(String args[]) {
        // display a welcome message 
        System.out.println("Welcome to the Code Tester" + "\n" );
      
        //Initialize and work with more variables
        double x = 3;
        double y = 5;
        System.out.println("The value of x is: " + x + "\n");
        System.out.println("The value of y is: " + y + "\n");
        //Work with arithmetic expressions
        System.out.println("3 / 5 =  " + x / y + "\n");
        //Work with escape sequences
        System.out.println("Could not find folder named \"C:\\Program Files\\Test\"" + "\n");
        // Calculate the area of a rectangle
        double width = 4.25;
        System.out.println("Width: " + width + "\n");
        double length = 8.5;
        System.out.println("Length: " + length + "\n");
        width = 16.75;
        System.out.println("Width: " + width + "\n");
        double perimeter = (2 * width) + (2 * length);
        System.out.println("Perimeter: " + perimeter + "\n");
        
        
        // enter test code here
        
        System.out.println("Bye!");
    }
}
