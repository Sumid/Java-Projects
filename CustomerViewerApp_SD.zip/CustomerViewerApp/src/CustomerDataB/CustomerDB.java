package CustomerDataB;


import CustomerData.Customer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *@author Sumid Dhungel
 * A project to display customer information
 * Date: 09/09/2019
 * This program displays the customer information of the entered information is correct
 * else the application displays appropriate message that includes the customer number
**/
public class CustomerDB {
    public static Customer getCustomer(int customerNumber){
        if (customerNumber == 123) {
            return new Customer("Michael Martin","1376 Hill Street","Luckey","OH","43443");
        }
        else if (customerNumber == 124) {
            return new Customer("Marjorie Galvan","3144 Hillcrest Avenue","Cambridge","MA","02141");
        }
        else if (customerNumber == 125){
            return new Customer("Rebecca Cain","3572 New Street","Jefferson","OR","97352");
        }
        else if (customerNumber == 126){
            return new Customer("Sumid Dhungel","2800 Colorado Dr","Westminster","CO","80241");
        }
        else{
            return null;
        }
    }
} 
