package CustomerData;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *@author Sumid Dhungel
 * A project to display customer information
 * Date: 09/09/2019
 * This program displays the customer information of the entered information is correct
 * else the application displays appropriate message that includes the customer number
 */
public class Customer {
    private String name;
    private String address;
    private String city;
    private String state;
    private String ZipCode;

public Customer(String name, String address, String city, String state, String ZipCode){ // Constructor
    this.name = name;
    this.address = address;
    this.city = city;
    this.state = state;
    this.ZipCode = ZipCode;
}
public String getname(){
    return this.name;
}
public void setname(String name){
    this.name = name;
}
public String getaddress(){
    return this.address;
}
public void setaddress(String address){
    this.address = address;
}
public String getcity(){
    return this.city;
}
public void setcity(String city){
    this.city = city;
}
public String getstate(){
    return this.state;
}
public void setstate(String state){
    this.state = state; 
}
public String getZipCode(){
    return this.ZipCode;
}
public void setZipCode(String ZipCode){
    this.ZipCode = ZipCode;
}
//returns the customer information as the format shown in question
public String getNameAndAddress(){
   return name + "\n" + address + "\n" + city + ", " + state + " " + ZipCode;
  
}
}
