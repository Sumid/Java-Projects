package CustomerDataC;


import CustomerDataB.CustomerDB;
import CustomerData.Customer;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *@author Sumid Dhungel
 * A project to display customer information
 * Date: 09/09/2019
 * This program displays the customer information of the entered information is correct
 * else the application displays appropriate message that includes the customer number
 */
public class CustomerViewerApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        Scanner scanner = new Scanner(System.in);

        System.out.println("Customer Viewer: Version 1.0");

        String choice = "y";
        while (choice.equalsIgnoreCase("y")) {
  
            System.out.print("\nEnter a customer number: ");

            int num = scanner.nextInt();
    
            Customer customer = CustomerDB.getCustomer(num);
        if (customer == null) {
            System.out.println("There is no customer number " + num + " to display");
        }
        else {
            System.out.println("\n" + customer.getNameAndAddress());
        }
            System.out.print("\nDisplay another customer? (y/n) ");

        choice = scanner.next();
    }
        
    }
    
    } 
