/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package murach.games;

import java.util.Random;

/**
 *
 * Sumid Dhungel
 * Date: 08/28/19
 * Number guessing game
 */
public class NumberGame {
    //Creating Instance Variables
    private int upperLimit;
    private int number;
    private int numberGuessed;
    //Adding a constructor
    public NumberGame(int upperLimit){
    this.upperLimit = upperLimit;
    //Cutting and pasting lines from main.java
    Random random = new Random();
    this.number = random.nextInt(upperLimit + 1);
    //initializing the instance variable for the number of guesses to 1
    this.numberGuessed = 1;
    }
    public NumberGame(){
        this(50);
    }
    public int getUpperLimit(){
        return upperLimit;
    }
    public int getNumber(){
        return number;
    }
    public int getNumberGuessed(){
        return numberGuessed;
    }
    public void incrementGuessCount(){
        numberGuessed++;
    }
}
